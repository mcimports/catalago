import {
    parsePhoneNumberFromString as parsePhoneNumber
} from 'https://cdn.jsdelivr.net/npm/libphonenumber-js@1.10.47/+esm'

window.i18nPhone = class i18nPhone {
    constructor(number, regionCode) {
        this.phoneNumberObj = null;

        if (number != undefined) {
            this.parse(number, regionCode);
        }
    }

    parse(number, regionCode) {
        this.phoneNumberObj = parsePhoneNumber(number, regionCode);

        return this;
    }

    parseDB(E164number, number) {
        if (E164number != undefined && E164number.length > 0) {
            if (!E164number.startsWith('+')) {
                E164number = '+' + E164number;
            }
            this.parse(E164number.toString(), null);

            return this;
        }

        if (number != undefined && number.length > 0) {
            this.parse(number.toString(), 'BR');
        }

        return this;
    }

    getNationalNumber() {
        if (!this.phoneNumberObj) {
            return null;
        }

        return this.phoneNumberObj.formatNational();
    }

    getNationalNumberWithFlag() {
        if (!this.phoneNumberObj) {
            return null;
        }

        let regionCode = `${this.phoneNumberObj.country}`.toLowerCase();
        let number = this.phoneNumberObj.formatNational();

        return `<span class="fi fi-${regionCode}"></span> ${number}`;
    }

    getE164Number(includePlusSign = true) {
        if (!this.phoneNumberObj) {
            return null;
        }

        let number = this.phoneNumberObj.format('E.164');

        if (includePlusSign === false) {
            number = number.replace('+', '');
        }

        return number;
    }
}

window.inputPhonei18n = class inputPhonei18n {
    constructor(seletor) {
        this.seletor = seletor;
    }

    exists() {
        return $(this.seletor).length > 0;
    }

    loaded() {
        return $(`${this.seletor} .inputPhonei18n-e164`).length > 0;
    }

    invalid() {
        return $(`${this.seletor} .inputPhonei18n-raw`).is(":invalid");
    }

    setNumber(number) {
        $(`${this.seletor} .inputPhonei18n-update`).val(number);
        $(`${this.seletor} .inputPhonei18n-update`).change();
    }

    setDBNumber(E164Number, number) {
        let finalNumber = '+55' + number;

        if (E164Number) {
            finalNumber = E164Number;
        }

        this.setNumber(finalNumber);
    }

    empty() {
        this.setNumber('+55');
    }

    getE164Number() {
        return $(`${this.seletor} .inputPhonei18n-e164`).val();
    }

    getDDI() {
        return $(`${this.seletor} .inputPhonei18n-ddi`).val();
    }

    getCountry() {
        return $(`${this.seletor} .inputPhonei18n-country`).val();
    }

    getRaw() {
        return $(`${this.seletor} .inputPhonei18n-raw`).val();
    }
}