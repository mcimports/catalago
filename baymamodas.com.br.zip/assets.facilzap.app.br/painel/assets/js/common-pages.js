"use strict";
$(document).ready(function() {
    // $('.theme-loader').addClass('loaded');
    $('.theme-loader').animate({
        'opacity': '0',
    }, 400);
    setTimeout(function() {
        $('.theme-loader').remove();
    }, 800);
    // $('.pcoded').addClass('loaded');
});