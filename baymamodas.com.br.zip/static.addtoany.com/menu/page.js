! function(o, i) {
    function r() {}
    var n, d, e, l, a, t, s, c, u, f, p, y, m, v, h, _, g = "addtoany",
        E = ".oafg07ee",
        k = o.head;
    "function" == typeof [].indexOf && k && (i.a2a = i.a2a || {}, n = i.a2a_config = i.a2a_config || {}, _ = (d = o.currentScript instanceof HTMLScriptElement ? o.currentScript : null) && d.src ? d.src : "", e = d && !d.async && !d.defer, NodeList && NodeList.prototype.forEach && (i.a2a.init = function(e, t) {
        void 0 === t && (t = n);
        var a = ":not([data-a2a-url]):not(.a2a_target)";
        o.querySelectorAll(".a2a_dd" + a + ",.a2a_kit" + a).forEach(function(e) {
            e.matches(".a2a_kit .a2a_dd");
            e.a2a_index || null !== e.getAttribute("data-a2a-url") || e.matches(".a2a_kit .a2a_dd") || (e.dataset.a2aUrl = t.linkurl || "", t.linkname && (e.dataset.a2aTitle = t.linkname))
        }), delete n.linkurl, delete n.linkname
    }, i.a2a_init = i.a2a.init, e) && i.a2a.init("page", {
        linkurl: n.linkurl,
        linkname: n.linkname
    }), i.a2a.page || (i.a2a.page = !0, l = [], ["init_all", "svg_css"].forEach(function(a) {
        i.a2a[a] = function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            l.push([a, e])
        }
    }), t = (a = n.static_server) ? a + "/" : "https://static.addtoany.com/menu/", m = _ && -1 !== _.split("/")[2].indexOf(g), s = (m = (s = !a && m ? _ : t).match(/^[^?#]+\//)) ? m[0] : s, c = function(e, t, a) {
        void 0 === e && (e = s + "eso" + E + ".js"), void 0 === t && (t = !1);
        var n = o.createElement((a = void 0 === a ? !1 : a) ? "link" : "script"),
            i = "module",
            a = (a ? (a = "preload", n.href = e, n.rel = t ? i + a : a, t || (n.as = "script")) : (n.src = e, t && (n.type = i, n.onerror = function() {
                return c()
            })), d && d.nonce ? d.nonce : null);
        a && (n.nonce = a), k.appendChild(n)
    }, u = function() {
        var e = s + (a ? "" : "modules/");
        c(e + "core" + E + ".js", !0);
        var t = o.createElement("link").relList.supports("modulepreload");
        n.overlays && n.overlays.length && t && c(e + "overlays" + E + ".js", !0, !0), u = r
    }, p = "a2a_sm_ifr", y = function() {
        var e, t, a, n;
        t = "a2a_menu_container", e = o.getElementById(t), i.a2a.main = f = e || o.createElement("div"), f.id != t && (o.getElementById(g) || (f.id = g), f.style.position = "static", o.body.insertBefore(f, null)), i.addEventListener("message", function(e) {
            var t = e.origin;
            t && ".addtoany.com" !== t.substr(-13) || "object" == typeof(t = e.data) && t.a2a && (t.h1 && (i.a2a.h1 = !0), "function" == typeof(e = i.a2a.userServices) ? e(t.user_services) : i.a2a.userServices = t.user_services, o.getElementById(p).style.display = "none")
        }), e = o.createElement("iframe"), t = o.createElement("div"), a = e.style, n = t.style, e.id = p, a.width = a.height = n.width = n.height = "1px", a.top = a.left = a.border = "0", a.position = n.position = "absolute", a.zIndex = n.zIndex = "100000", e.title = "AddToAny Utility Frame", e.setAttribute("aria-hidden", "true"), e.src = "https://static.addtoany.com/menu/sm.25.html#type=core&event=load", n.top = "0", n.visibility = "hidden", f.insertBefore(t, null), t.insertBefore(e, null), y = r
    }, o.body && y(), "function" == typeof(_ = "".matchAll) && _.toString().includes("[native code]") ? ("loading" !== o.readyState && u(), m = t + (a ? "" : "svg/"), o.querySelector('.a2a_dd:empty,.a2a_kit [class*="a2a_button_"]:empty') && i.a2a.h1 && c(m + "icons.39.svg.js", !1, !0)) : c(), v = function(e) {
        var t = i.a2a.core;
        "function" != typeof t || e ? e ? e() : i.a2a.core = function(e) {
            return v(e)
        } : t()
    }, _ = function() {
        h || (h = !0, u(), y(), v(), l.forEach(function(e) {
            var t;
            (t = i.a2a)[e[0]].apply(t, e[1])
        }))
    }, !(e && k.contains(d) || !o.body) || "loading" !== o.readyState ? _() : (o.addEventListener("readystatechange", _), o.addEventListener("DOMContentLoaded", _))))
}(document, window);